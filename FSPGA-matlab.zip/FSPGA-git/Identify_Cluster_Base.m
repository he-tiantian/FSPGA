function [cluster_number,overlapping_rate] = Identify_Cluster_Base(C,path,beta)
%   This function is used to identify Clusters after the matrix of
%   cluster affiliation is obtained.
%   Input: 
%   G, the matrix of weights representing the affliation of
%   clusters(Nv*K); 
%   A: adjacency matrix of network graph; 
%   phi: Gij is set to zero if Gij is lower than phi; 
%   tau: threshold that is used to control the overlapping rate;
%   path: directory to store the cluster file.
%
%   Output: 
%   cluster_number: The number of Clusters in C.

if(nargin==2)
    [~,K] = size(C);
	C = C./repmat(max(C,[],2),1,K);
    %C = C-repmat(max(C,[],2),1,K);
	C(isnan(C))=0;
    C(C<1)=0;
    C(C>0)=1;
elseif(nargin==3)
    [~,K] = size(C);
    temp = C./repmat(max(C,[],2),1,K);
    temp(isnan(temp))=0;
    temp(temp<1)=0;
    temp(temp>0)=1;
    C = C-(beta*sqrt(size(C,2)-1)+1)./size(C,2);
    C(C<0)=0;
    C = C+temp;
    C(C>0)=1;
else
    fprintf('Wrong setting of args!\n');
    return;
end

small_clusters=sum(C)<1;
C = C(:, ~small_clusters);
X = unique(C','rows');
C = X';
[~,K1] = size(C);

Inter = C'*C;
Inter = triu(Inter,1);
U = zeros(K1,K1);
for i=1:K1-1;
    ci = C(:,i);
    for j = i+1:K1
        cj=C(:,j);
        temp = ci+cj;
        temp(temp>0)=1;
        U(i,j)=sum(temp);
    end
end

%dlmwrite('c',sum(C,2));
Inter = Inter./U;
Inter(isnan(Inter))=0;
o = sum(sum(Inter));
overlapping_rate = 2*o./(K1*K1-K1);
%overlapping_rate = (o'*o)./Nv;


fid = fopen(strcat(path,'K=',num2str(K),'.Cluster'), 'w');
count = 0;
for k=1:K1
   index_k = find(C(:,k));
   if(~isempty(index_k))
      count = count + 1;
      fprintf(fid, '%s\n', strcat('Cluster #',num2str(count)));
      for i= 1:length(index_k)
          fprintf(fid, '%s\t',num2str(index_k(i)-1));
      end
      fprintf(fid, '\n');
    end
        
end
fclose(fid);
cluster_number = count;

end


