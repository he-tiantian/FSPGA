function [ ] = FSPGA_D( )
%The distributed version of FSPGA. This version can be used to record
% results in detail obtained in each trial of experiment, including
% objective values, parameter settings and strength matrices.
%Input:
%K:The number of clusters
%MaxIter: maximum number of iterations of updating;
%MiniGap: minimum objective value between two iteration;
%path:file folder storing information on edgelist and attribute association
%list
%alpha: weight that balances the bias between structure and attribute
%association (Default using 0.5 for experiment)
%beta: parameter for controling the overlapping rates

fprintf('Loading graph data and node attributes...\n'); 
path = '';
P = load('Config.txt');
K = P(1);
alpha = P(2);
beta = P(3);
Max_Iter = P(4);
Mini_Gap=P(5);

%contatenate string for data directory

[M,F,Nv,~] = Loadedgelist_C( );
A = Proximal_Matrix(F,1);
A = A - diag(diag(A));

M = full(M);
A = full(A);

fprintf('Data loaded, now initializing indicator matrices...\n');

%Initializing Cluster indicator matrix
C = rand(Nv,K); C = C./repmat(sum(C,2),1,K); C_old = C;
%Initializing indicator matrix of structure strength X1
X1 = rand(Nv,K); 
%Initializing indicator matrix of attribute association strength X2
X2 = rand(Nv,K);

e = 1.0e-25;
E2 = ones(Nv,1);

%Vector for recording objective values after each iteration of updating.
Objective = (1:Max_Iter);

%The optimization procedure
fprintf('Optimization process begins...\n');
tic;
for i=1:Max_Iter
    
    %Updating Cluster indicator matrix
    T_N = alpha*M*X1+(1-alpha)*A*X2;
    T_D = C*(X2'*X2)+C*(X1'*X1)+C;
    lambda = (sum(C.*(T_N./T_D),2)-E2)./(sum(C./T_D,2));
    C = C.*((T_N-repmat(lambda,1,K))./T_D);
    C(C<e)=e;
    
    %updating X
    X1 = X1.*((alpha*M*C)./(X1*(C'*C)+X1));
    X2 = X2.*(((1-alpha)*A*C)./(X2*(C'*C)+X2));
    X1(X1<e)=e;
    X2(X2<e)=e;
    
    del_G = C-C_old;
    C_old = C;
    Objective(1,i)=sqrt(trace(del_G'*del_G));
    
   if(i>1&&i<Max_Iter)
      if(Objective(1,i)<Mini_Gap)
          Obj=alpha*trace(C'*M*X1)+(1-alpha)*trace(C'*A*X2)-0.5*trace(C*(X2'*X2)*C')-0.5*trace(C*(X1'*X1)*C')-0.5*trace(C'*C)-0.5*trace(X1'*X1)-0.5*trace(X2'*X2);
          fprintf('The variation of cluster membership matrix C after iteration %d is less than Minimum Gap %f, the algorithm is terminated.\n', i, Mini_Gap);         
          fprintf('The final Objective value is %f.\n', Obj);
          Objective = Objective(1,1:i);
          break;
      end
      if(mod(i,50)==0)
          Obj=alpha*trace(C'*M*X1)+(1-alpha)*trace(C'*A*X2)-0.5*trace(C*(X2'*X2)*C')-0.5*trace(C*(X1'*X1)*C')-0.5*trace(C'*C)-0.5*trace(X1'*X1)-0.5*trace(X2'*X2);
          fprintf('The Objective value after iteration %d is %f.\n', i, Obj);
      end 
   else
       Obj=alpha*trace(C'*M*X1)+(1-alpha)*trace(C'*A*X2)-0.5*trace(C*(X2'*X2)*C')-0.5*trace(C*(X1'*X1)*C')-0.5*trace(C'*C)-0.5*trace(X1'*X1)-0.5*trace(X2'*X2);
       fprintf('The Objective value after iteration %d is %f.\n', i, Obj);
   end
end

time = toc;
fprintf('Optimization is done, saving recording information and indicator matrices...\n');

C(C<=e)=0;
X2(X2<=e)=0;
X1(X1<=e)=0;
X = [X1
    X2];
path = strcat('.\',path,'\');
prefix=strcat('K=',num2str(K));
dlmwrite(strcat(path,prefix,'_C'),C);
dlmwrite(strcat(path,prefix,'_X'),X);

fid = fopen(strcat(path,prefix,'.log'), 'w');
fprintf(fid, 'Parameters setting:\n');
fprintf(fid, 'Alpha:%s\tBeta:%s\te:%s\tK:%s\tMini_Gap:%s\n',num2str(alpha),num2str(beta),num2str(e),num2str(K),num2str(Mini_Gap));
fprintf(fid, 'Optimization Time: %s\n', num2str(time));
fprintf(fid, 'Total time consumption: %s\n', num2str(time));
fprintf(fid, 'The number of iterations: %s\n', num2str(size(Objective,2)));
fprintf(fid, 'Time consumption per iteration: %s\n', num2str(time/size(Objective,2)));

fclose(fid);
fprintf('Recording information and indicator matrices saved.\n');

%fprintf('Identifying clusters...\n');

if(beta>0)
    fprintf('Identifying overlapping clusters...\n');
    % ordinary attributed graph
    Identify_Cluster_Base(C,path,beta);
else
    fprintf('Identifying disjoint clusters...\n');
    % ordinary attributed graph
    Identify_Cluster_Base(C,path);


end
end

function [ D,F,n,m ] = Loadedgelist_C( )
% Load edgelist and construct matrices for DCNLA
%path = strcat('.\', path,'\');
info= load('statistics');
n = info(1,1);
m = info(3,1);
edgelist=load('edgelist');
edgelist=edgelist+1;
D = sparse(cat(1,edgelist(:,1),edgelist(:,2)),cat(1,edgelist(:,2),edgelist(:,1)),ones(size(cat(1,edgelist(:,1),edgelist(:,2)),1),1),n,n);

similaritylist=load('vertex2aid');
similaritylist(:,1)=similaritylist(:,1)+1;
similaritylist(:,2)=similaritylist(:,2)+1;
%A = sparse(cat(1,similaritylist(:,1),similaritylist(:,2)),cat(1,similaritylist(:,2),similaritylist(:,1)),cat(1,similaritylist(:,3),similaritylist(:,3)),Nv,Nv);

F = sparse(similaritylist(:,2),similaritylist(:,1),ones(size(similaritylist,1),1),m, n);

end


