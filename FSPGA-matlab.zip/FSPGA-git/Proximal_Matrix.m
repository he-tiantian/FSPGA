function [P] = Proximal_Matrix(X,para)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
if para==1
    P = X'*X;
    a = sqrt(diag(P));
    P = P./(a*a');
    P(isnan(P))=0;
else
    P = X'*X;
    % sigma = 2 by default
    sigma = 2;
    P = (2*P - repmat(diag(P),1,n)-repmat(diag(P)',n,1))./(2*sigma*sigma);
    P = exp(P);
    P = P-diag(diag(P));
end

end

